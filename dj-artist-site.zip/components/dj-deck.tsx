'use client'

import { ExternalLink, Pause, Play, Radio, SkipBack, SkipForward } from 'lucide-react'
import { useEffect, useState } from 'react'

const tracks = [
  { title: 'Mumbai After Dark', meta: 'Live edit / 126 BPM', href: 'https://open.spotify.com/' },
  { title: 'Monsoon Frequency', meta: 'Original mix / 124 BPM', href: 'https://open.spotify.com/' },
  { title: 'Room 404', meta: 'Club cut / 128 BPM', href: 'https://open.spotify.com/' },
]

const waveform = [18, 42, 28, 66, 38, 80, 56, 30, 72, 46, 88, 62, 34, 74, 52, 92, 44, 68, 30, 58, 76, 40, 84, 48, 24, 62, 38, 72, 50, 86, 32, 64, 42, 78, 54, 70]

export default function DJDeck() {
  const [track, setTrack] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [progress, setProgress] = useState(34)

  useEffect(() => {
    if (!playing) return
    const timer = window.setInterval(() => setProgress((value) => value >= 100 ? 0 : value + 1), 900)
    return () => window.clearInterval(timer)
  }, [playing])

  const current = tracks[track]

  return <div className="dj-deck-shell">
    <div className="dj-deck-topline"><span><Radio size={13} /> Live deck / {current.meta}</span><span>Ganesh FM · 0{track + 1} / 03</span></div>
    <div className="dj-deck-grid">
      <div className="turntable turntable-left"><div className={`platter ${playing ? 'platter-playing' : ''}`}><div className="platter-label">G</div></div><div className="tonearm" /></div>
      <div className="deck-center"><div className="deck-track"><div><p className="font-mono text-[10px] uppercase tracking-widest text-accent">Now selecting</p><h3>{current.title}</h3></div><a href={current.href} target="_blank" rel="noreferrer" aria-label={`Open ${current.title} on Spotify`}><ExternalLink size={16} /></a></div><div className="waveform" aria-label="Animated track waveform">{waveform.map((height, index) => <span key={index} className={index / waveform.length * 100 < progress ? 'wave-active' : ''} style={{ height: `${height}%`, animationDelay: `${index * 35}ms` }} />)}</div><div className="deck-progress"><span>00:{Math.floor(progress * .42).toString().padStart(2, '0')}</span><div><i style={{ width: `${progress}%` }} /></div><span>04:20</span></div><div className="deck-controls"><button aria-label="Previous track" onClick={() => setTrack((track + tracks.length - 1) % tracks.length)}><SkipBack size={18} /></button><button aria-label={playing ? 'Pause track' : 'Play track'} className="deck-play" onClick={() => setPlaying(!playing)}>{playing ? <Pause size={22} /> : <Play size={22} fill="currentColor" />}</button><button aria-label="Next track" onClick={() => setTrack((track + 1) % tracks.length)}><SkipForward size={18} /></button></div></div>
      <div className="turntable turntable-right"><div className={`platter platter-small ${playing ? 'platter-playing' : ''}`}><div className="platter-label">01</div></div><div className="mixer-fader"><i /><i /><i /><i /></div></div>
    </div>
    <div className="deck-track-list">{tracks.map((item, index) => <button key={item.title} onClick={() => { setTrack(index); setPlaying(true) }} className={track === index ? 'track-selected' : ''}><span>0{index + 1}</span><strong>{item.title}</strong><small>{item.meta}</small><Play size={13} /></button>)}</div>
  </div>
}
