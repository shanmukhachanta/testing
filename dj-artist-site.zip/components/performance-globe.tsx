'use client'

import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Stars } from '@react-three/drei'
import { useRef } from 'react'
import * as THREE from 'three'

const cities = [
  { name: 'Mumbai', lat: 19.076, lon: 72.877 },
  { name: 'Dubai', lat: 25.204, lon: 55.270 },
  { name: 'Singapore', lat: 1.352, lon: 103.819 },
  { name: 'London', lat: 51.507, lon: -0.128 },
  { name: 'New York', lat: 40.712, lon: -74.006 },
  { name: 'Bengaluru', lat: 12.971, lon: 77.594 },
  { name: 'Bangkok', lat: 13.756, lon: 100.501 },
]

function point(lat: number, lon: number, radius = 1.52) {
  const phi = (90 - lat) * (Math.PI / 180)
  const theta = (lon + 180) * (Math.PI / 180)
  return [-(radius * Math.sin(phi) * Math.cos(theta)), radius * Math.cos(phi), radius * Math.sin(phi) * Math.sin(theta)] as [number, number, number]
}

function GlobeMesh() {
  const globe = useRef<THREE.Mesh>(null)
  useFrame((_, delta) => { if (globe.current) globe.current.rotation.y += delta * 0.055 })
  return <>
    <mesh ref={globe} rotation={[0.18, -0.8, 0]}>
      <sphereGeometry args={[1.5, 64, 64]} />
      <meshStandardMaterial color="#0b2930" roughness={0.78} metalness={0.18} emissive="#071d25" emissiveIntensity={0.55} />
    </mesh>
    <mesh rotation={[0.18, -0.8, 0]}>
      <sphereGeometry args={[1.54, 48, 48]} />
      <meshBasicMaterial color="#39e6c4" transparent opacity={0.12} wireframe />
    </mesh>
    {cities.map((city) => <CityMarker key={city.name} city={city} />)}
  </>
}

function CityMarker({ city }: { city: (typeof cities)[number] }) {
  const position = point(city.lat, city.lon)
  return <group position={position}><mesh><sphereGeometry args={[0.035, 12, 12]} /><meshBasicMaterial color="#f5c46b" /></mesh><mesh scale={1.8}><sphereGeometry args={[0.035, 12, 12]} /><meshBasicMaterial color="#f5c46b" transparent opacity={0.2} /></mesh></group>
}

export default function PerformanceGlobe() {
  return <div className="h-[420px] w-full overflow-hidden rounded-[2rem] border border-border/60 bg-[#071217] sm:h-[560px] lg:h-[640px]" aria-label="Interactive 3D globe showing cities where DJ Ganesh has performed"><Canvas camera={{ position: [0, 0, 4.2], fov: 36 }} dpr={[1, 1.6]}><color attach="background" args={['#071217']} /><ambientLight intensity={1.3} /><directionalLight position={[3, 2, 4]} intensity={3} color="#b9fff2" /><pointLight position={[-3, -2, 2]} intensity={14} distance={7} color="#f5c46b" /><Stars radius={7} depth={3} count={900} factor={1.4} saturation={0} fade speed={0.3} /><GlobeMesh /><OrbitControls enableZoom={false} autoRotate autoRotateSpeed={0.35} enablePan={false} /></Canvas></div>
}

export { cities }

